def add(a, b):
    return a + b


def inv(a, b):
    return a / b
