class CPU:
    pass
